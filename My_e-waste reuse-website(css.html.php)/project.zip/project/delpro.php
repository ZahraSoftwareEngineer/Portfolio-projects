<?php
$dbconnect=mysqli_connect("localhost","root","") ;
$use=mysqli_select_db($dbconnect,5);

$pid=$_POST['productid'];

if (isset($_POST['del'])) 
{
$del=mysqli_query($dbconnect,"DELETE FROM prodect WHERE 'Id=$pid' " );


if($del)
echo "<br><h4>Record Deleted<br>";
else
echo "<br><h4>Record not Deleted<br>";
}
?>