<html>
<head>
<title>Add Product</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inconsolata">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box}


input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}


input[type=number]:focus, input[type=number]:focus {
  background-color: #ddd;
  outline: none;
}

input[type=number], input[type=number] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}


button {
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

button:hover {
  opacity:1;
}

.cancelbtn {
  padding: 14px 20px;
  background-color: #f44336;
}


.cancelbtn, .signupbtn {
  float: left;
  width: 50%;
}

.container {
  padding: 16px;
}


.clearfix::after {
  content: "";
  clear: both;
  display: table;
}


@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
     width: 100%;
  }
}
</style>
</head>
<body>
<div class="w3-top">
  <div class="w3-row w3-padding w3-black">
    
    <div class="w3-col s3">
      <a href="buy_product.html" class="w3-button w3-block w3-black">Home</a>
    </div>
  </div>
</div>
<form action="addAgent.php" method="POST" style="border:1px solid #ccc">
  <div class="container">
    <hr>
	<h1>Agent Details</h1>
    <p>Please fill in this form the details of Agent.</p>
    </hr>
<label for="agentid"><b>Agent ID</b></label>
    <input type="text" placeholder="Enter Agent ID" name="agentid" required>

        <label for="agentname"><b>Agent Name</b></label>
    <input type="text" placeholder="Enter Agent name" name="agentname" required>

	<label for="number"><b>Phone Number</b></label>
    <input type="number" placeholder="Enter Phone Number" name="phone" required>
	
    <label for="loc"><b>Location</b></label>
    <input type="text" placeholder="Enter your location" name="loc" required>

	
	
    
      <div class="clearfix">
 <input type="submit" name="b1" value="Add" >

     


      
    </div>
  </div>
</form>

<footer class="w3-center w3-light-grey w3-padding-48 w3-large">
  
</footer>
</body>
</html>