<?php
$dbconnect=mysqli_connect("localhost","root","") ;
$db=mysqli_select_db($dbconnect,"5");
$compid=$_POST['compid'];
$compname=$_POST['compname'];
$protyp=$_POST['protyp'];
$len=strlen($compid); 
$error=0;
if(empty($compid))
{
echo"Please enter company ID<br><br>";
$error=1;
}
else if($len!=4)
{
echo"<br><br><br><br>Please enter Company ID is 4 digits only<br><br>";
$error=1;
}
if(empty($compname))
{
echo"Please enter company Name<br><br>";
$error=1;
}
else if(!preg_match("/^[a-zA-Z'-]+$/",($compname)))
{
echo"<br><br><br><br>Please enter alphabets only for Company Name";
$error=1;
}
if(empty($protyp))
{
echo"<br><br><br><br>Please enter Product Type<br><br>";
$error=1;
}
if($error==0)
if (isset($_POST['b1'])) 
{
$in=mysqli_query($dbconnect,"INSERT INTO recycling_company VALUES('$compid','$compname','$protyp')");

if($in)
echo "<br><h4>Recored Saved<br>";
else
echo "<br><h4>Record Not Saved<br>";
}
?>