<?php
$abc=mysqli_connect("localhost","root","");
$db=mysqli_select_db($abc,"5");
$pid=$_POST['productid'];
$pname = $_POST['productname']; 
$ptype= $_POST['producttype']; 
$pdesc= $_POST['description']; 
$pqty= $_POST['qty']; 
$len=strlen($pid); 
$lend=strlen($pdesc);
$error=0;
if(empty($pid))
{
echo"Please enter product ID<br><br>";
$error=1;
}
else if($len!=4)
{
echo"<br><br><br><br>Please enter product ID is 4 digits only<br><br>";
$error=1;
}
if(empty($pname))
{
echo"<br><br><br><br>Please enter Product Name<br><br>";
$error=1;
}
if(!preg_match("/^[a-zA-Z'-]+$/",($pname)))
{
echo"<br><br><br><br>Please enter alphabets only for product Name";
$error=1;
}
if(empty($ptype))
{
echo"<br><br><br><br>Please enter Product Type<br><br>";
$error=1;
}
if(empty($pdesc))
{
echo"<br><br><br><br>Please enter Description of Product<br><br>";
$error=1;
}
else if($lend>=500)
{
echo"<br><br>Please enter Password less than 500 digits";
$error=1;
}
if(empty($pqty))
{
echo"<br><br><br><br>Please enter of quantity Product<br><br>";
$error=1;
}
if($error==0)
{
if (isset($_POST['b1'])) 
{
$in=mysqli_query($abc,"INSERT INTO product VALUES('$pid','$pname','$ptype','$pdesc','$pqty')");
if($in)
echo "<br><h4>Recored Saved<br>";
else
echo "<br><h4>Record Not Saved<br>";
}
}
?>