<?php

$abc=mysqli_connect("localhost","root","");
$date=mysqli_select_db($abc,"5");

$nationalid = $_POST['nationalid']; 
$pass= $_POST['psw'];
$len=strlen($nationalid);
$lenp=strlen($pass); 
$error=0;
if(empty($nationalid))
{
echo"Please enter your National Number<br><br>";
$error=1;
}
else if($len!=8)
{
echo"<br><br><br><br>Please enter National Number is 8 digits only<br><br>";
$error=1;
}
if(empty($pass))
{
echo"<br><br>Please enter your Password";
$error=1;
}
else if($lenp<=8)
{
echo"<br><br>Please enter Password more than 8 digits";
$error=1;
}
if($error==0)
if(isset($_POST['b1']))
{
$sel=mysqli_query($abc,"SELECT * from register");
echo "<table width='50%' border='2'>";
echo "<tr><th>National ID</th><th>Password</th></tr>";
$Row = mysqli_fetch_row($sel);
do {
echo "<tr><td> {$Row[0]} </td>";
echo "<td> {$Row[1]} </td>";
$Row = mysqli_fetch_row($sel);
}while($Row);
}



?>
