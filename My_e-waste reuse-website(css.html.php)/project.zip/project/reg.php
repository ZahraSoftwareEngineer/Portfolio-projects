<?php
$abc=mysqli_connect("localhost","root","");
$date=mysqli_select_db($abc,"5");
$nationalid = $_POST['nationalid']; 
$name = $_POST['name'];
$pass= $_POST["psw"];  
$phoneno = $_POST['phoneno']; 
$email = $_POST["email"];
$len=strlen($nationalid);
$lenp=strlen($pass);
$lenh=strlen($phoneno);
$error=0;
if(empty($nationalid))
{
echo"Please enter your National Number<br><br>";
$error=1;
}
else if($len!=8)
{
echo"<br><br><br><br>Please enter National Number is 8 digits only<br><br>";
$error=1;
}
if(empty($name))
{
echo"<br><br><br><br>Please enter your Name<br><br>";
$error=1;
}
if(!preg_match("/^[a-zA-Z'-]+$/",($name)))
{
echo"<br><br><br><br>Please enter alphabets only for  Name";
$error=1;
}
if(empty($pass))
{
echo"<br><br>Please enter your Password";
$error=1;
}
else if($lenp<=8)
{
echo"<br><br>Please enter Password more than 8 digits";
$error=1;
}
if(empty($phoneno))
{
echo"<br><br>Please enter your Phone Number";
$error=1;
}
else if($lenh!=8)
{
echo"<br><br>Please enter Phone Number is 8 digits";
$error=1;
}
if(empty($email))
{
echo"<br><br>Please enter your Email";
$error=1;
}
if(!filter_var($email,FILTER_VALIDATE_EMAIL))
{
echo"<br><br>Please enter Email Correctly";
$error=1;
}
if($error==0)
if(isset($_POST['b1']))
{
$ins=mysqli_query($abc,"INSERT INTO register values('$nationalid','$name','$pass','$phoneno','$email')");
if($ins)
{
echo"<br><br><br><br><h2>Successful Registration</h2><br><br><br>";
echo "<h3>Click here to<a href='Login.html' style='color:dodgerblue'>   Login</a></h3>";
}
else
echo"<br><br><h2> Registration not Successful</h2>";
}
?>



<html>
<body>
<body>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inconsolata">
<style>
body, html {
  height: 100%;
  font-family: "Inconsolata", sans-serif;
}

.bgimg {
  background-position: center;
  background-size: cover;
  min-height: 75%;
}

.menu {
  display: none;
}
</style>
</head>
<body>
<style>
body, html {
  height: 100%;
  font-family: "Inconsolata", sans-serif;
}

.bgimg {
  background-position: center;
  background-size: cover;
  min-height: 75%;
}

.menu {
  display: none;
}
</style>
</head>

<div class="w3-top">
  <div class="w3-row w3-padding w3-black">
    <div class="w3-col s3">
      <a href="index.html" class="w3-button w3-block w3-black">Home</a>
    </div>
  </div>
</div>

<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<footer class="w3-center w3-light-grey w3-padding-48 w3-large">
  
</footer>
</body>
</html>