<?php
$abc=mysqli_connect("localhost","root","");
$db=mysqli_select_db($abc,"5");
$agentid=$_POST['agentid'];
$aname=$_POST['agentname'];
$anum=$_POST['phone'];
$loc=$_POST['loc'];
$len=strlen($agentid); 
$alen=strlen($anum);
$error=0;
if(empty($agentid))
{
echo"Please enter Agent ID<br><br>";
$error=1;
}
else if($len!=4)
{
echo"<br><br><br><br>Please enter Agent ID is 4 digits only<br><br>";
$error=1;
}
if(empty($aname))
{
echo"<br><br><br><br>Please enter Agent Name<br><br>";
$error=1;
}
else if(!preg_match("/^[a-zA-Z'-]+$/",($aname)))
{
echo"<br><br><br><br>Please enter alphabets only for Agent Name";
$error=1;
}
if(empty($anum))
{
echo"<br><br><br><br>Please enter Agent Name<br><br>";
$error=1;
}
else if($alen!=8)
{
echo"<br><br><br><br>Please enter Number Phone is 8 digits only<br><br>";
$error=1;
}
if(empty($loc))
{
echo"<br><br><br><br>Please enter Agent Name<br><br>";
$error=1;
}
else if(!preg_match("/^[a-zA-Z'-]+$/",($aname)))
{
echo"<br><br><br><br>Please enter alphabets only for Agent Name";
$error=1;
}
if($error==0)
if (isset($_POST['b1'])) 
{
$in=mysqli_query($abc,"INSERT INTO agent VALUES('$agentid','$aname','$anum','$loc')");
if($in)
echo "<br><h4>Recored Saved<br>";
else
echo "<br><h4>Record Not Saved<br>";
}
?>