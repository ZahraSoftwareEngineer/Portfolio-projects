
<?php
$dbconnect=mysqli_connect("localhost","root","") ;
$db=mysqli_select_db($dbconnect,"5");

$aid=$_POST['agentid'];

if (isset($_POST['b4'])) 
{
$del=mysqli_query($dbconnect,"DELETE FROM agent WHERE agentID=$aid");


if($del)
echo "<br><h4>Record Deleted<br>";
else
echo "<br><h4>Record not Deleted<br>";
}
?>